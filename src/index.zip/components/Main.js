import React from 'react';
import {Route, Switch, Redirect} from 'react-router-dom';
import Showcase from './Showcase';


function Main () {

    return(
        <Switch>
            <Route path='/home' component={Showcase} />
            {/* <Route path='/register' component={RegistrationForm} />
            <Route path='/clinician' component={ClinicianDashboard} />
            <Route path='/patient' component={NewPatient} />
            <Route path='/exercise' component={Exercise} /> */}
            <Redirect to="/home" />
        </Switch>
    )

}

export default Main;