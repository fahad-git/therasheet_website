import React from 'react';
import Header from './Header'
import Navbar from './Navbar';


function MainHeader (props) {

    const showHeader = props.showHeader;

    if(showHeader)
        return <Header />
    else
        return <Navbar />
}

export default MainHeader;