import React from 'react';
import '../assets/css/BasicComponents.css';

const Showcase = () => {
        return <div className="showcase">
                        <h2>Come and Register Today</h2>
                        <h1>Therasheet Clinic</h1>
                        <p>Therasheet clinic service providers</p>
                        <div className="showcase_button">
                                <button className="showcase_btn_login" >Login</button>
                                <button className="showcase_btn_register" >Register</button>
                        </div>
                </div>
}

export default Showcase;