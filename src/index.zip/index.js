import React, {useState} from 'react';
import ReactDom from 'react-dom';
import {BrowserRouter} from 'react-router-dom';
import './App.css'

import Showcase from './components/Showcase';
import MainHeader from './components/MainHeader';


const App = () => {

    const [showHeader, setHeader] = useState(false);


    return(
        <BrowserRouter>
        <div>
            <MainHeader showHeader={showHeader}/>
            <div className="main">
                <Showcase />
            </div>
        </div>
        </BrowserRouter>
    )
}

ReactDom.render(<App />, document.getElementById('root'));